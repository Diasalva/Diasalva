﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Wargame2
{

    public partial class Form1 : Form
    {
        class Card
        {
            
            public string Name;
            public int Value;
            public string Suit;          
            public override string ToString() { return string.Format("{0} of {1}", Name, Suit); }
            public const int NCARDS = 52;         
            
        }
        static List<Card> DeckOfCard { get; set; } = new List<Card>
            {

                    new Card{Name=" two",Value=2,Suit=" ♥ Heart"},
                    new Card{Name=" three",Value=3,Suit=" ♥ Heart"},
                    new Card{Name=" four",Value=4,Suit=" ♥ Heart"},
                    new Card{Name="five", Value=5, Suit=" ♥ Heart"},
                    new Card{Name=" six",Value=6,Suit=" ♥ Heart"},
                    new Card{Name="seven",Value=7,Suit=" ♥ Heart"},
                    new Card{Name="eight",Value=8,Suit=" ♥ Heart"},
                    new Card { Name="Nine", Value=9, Suit=" ♥ heart"},
                    new Card{Name="ten",Value=10,Suit=" ♥ Heart"},
                    new Card{Name="jack",Value=11,Suit=" ♥ Heart"},
                    new Card{Name="queen",Value=12,Suit=" ♥ Heart"},
                    new Card { Name="king", Value=13, Suit=" ♥ heart"},
                    new Card { Name="Ace", Value=14, Suit=" ♥ Heart"},


                    new Card{Name="two",Value=2,Suit=" ♠ Spades"},
                    new Card{Name="three",Value=3,Suit=" ♠ Spades"},
                    new Card{Name="four",Value=4,Suit=" ♠ Spades"},
                    new Card { Name="five", Value=5, Suit=" ♠ Spades"},
                    new Card{Name="six",Value=6,Suit=" ♠ Spades"},
                    new Card{Name="seven",Value=7,Suit=" ♠ Spades"},
                    new Card{Name="eight",Value=8,Suit=" ♠ Spades"},
                    new Card { Name="Nine", Value=9, Suit=" ♠ Spades"},
                    new Card{Name="ten",Value=10,Suit=" ♠ Spades"},
                    new Card{Name="jack",Value=11,Suit=" ♠ Spades"},
                    new Card{Name="queen",Value=12,Suit=" ♠ Spades"},
                    new Card { Name="king", Value=13, Suit=" ♠ Spades"},
                    new Card { Name="Ace", Value=14, Suit=" ♠ Spades"},


                    new Card{Name="two",Value=2,Suit=" ♦ Diamonds"},
                    new Card{Name="three",Value=3,Suit=" ♦ Diamonds"},
                    new Card{Name="four",Value=4,Suit=" ♦ Diamonds"},
                    new Card { Name="five", Value=5, Suit=" ♦ Diamonds"},
                    new Card{Name="six",Value=6,Suit=" ♦ Diamonds"},
                    new Card{Name="seven",Value=7,Suit=" ♦ Diamonds"},
                    new Card{Name="eight",Value=8,Suit=" ♦ Diamonds"},
                    new Card { Name="Nine", Value=9, Suit=" ♦ Diamonds"},
                    new Card{Name="ten",Value=10,Suit=" ♦ Diamonds"},
                    new Card{Name="jack",Value=11,Suit="♦ Diamonds"},
                    new Card{Name="queen",Value=12,Suit=" ♦ Diamonds"},
                    new Card { Name="king", Value=13, Suit=" ♦ Diamonds"},
                    new Card { Name="Ace", Value=14, Suit=" ♦ Diamonds"},

                    new Card{Name="two",Value=2,Suit=" ♣ Clubs"},
                    new Card{Name="three",Value=3,Suit=" ♣ Clubs"},
                    new Card{Name="four",Value=4,Suit=" ♣ Clubs"},
                    new Card { Name="five", Value=5, Suit=" ♣ Clubs"},
                    new Card{Name="six",Value=6,Suit=" ♣ Clubs"},
                    new Card{Name="seven",Value=7,Suit=" ♣ Clubs"},
                    new Card{Name="eight",Value=8,Suit=" ♣ Clubs"},
                    new Card { Name="Nine", Value=9, Suit=" ♣ Clubs"},
                    new Card{Name="ten",Value=10,Suit=" ♣ Clubs"},
                    new Card{Name="jack",Value=11,Suit=" ♣ Clubs"},
                    new Card{Name="queen",Value=12,Suit=" ♣ Clubs"},
                    new Card { Name="king", Value=13, Suit=" ♣ Clubs"},
                    new Card { Name=" ♣Ace", Value=14, Suit=" ♣Clubs"},

         };
        List<Card> deckOfPlayer1 = new List<Card>();
        List<Card> deckOfPlayer2 = new List<Card>();
        public Form1()
        {
            InitializeComponent();

            int count = DeckOfCard.Count;

            for (int i = 0; i < DeckOfCard.Count; i++)
            {

                label7.Text = ($" We have {DeckOfCard.Count} cards for this game, let's flip cards ");

            }

            Random random = new Random();

            for (int i = 0; i < 26; i++)
            {

                Card c1 = DeckOfCard[random.Next(DeckOfCard.Count)];
                deckOfPlayer1.Add(c1);
                DeckOfCard.Remove(c1);

                Card c2 = DeckOfCard[random.Next(DeckOfCard.Count)];
                deckOfPlayer2.Add(c2);
                DeckOfCard.Remove(c2);


                label1.Text = ($"Player1 has {deckOfPlayer1.Count} CARDS!");
                label2.Text = ($"Player2 has {deckOfPlayer2.Count} CARDS!");
            }

        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void label2_Click(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {

            label1.Text = "";
            label2.Text = "";
            label3.Text = "";
            label4.Text = "";
            label5.Text = "";
            label7.Text = "";

            // pick  The TOP random card for player 1

            Card c1 = deckOfPlayer1[0];

            // pick The Top  random card for player 2              

            Card c2 = deckOfPlayer2[0];



            if (c1.Value > c2.Value)
            {

                label1.Text = ($"Player1 wins with {c1} as the top card");
                label2.Text = ($"Player2 lost with {c2} as the top card");
                deckOfPlayer1.Add(c2);
                deckOfPlayer2.Remove(c2);
                deckOfPlayer1.Add(c1);
                deckOfPlayer1.Remove(c1);
                label3.Text = ($"Player1 has {deckOfPlayer1.Count} ");
                label4.Text = ($"Player2 has {deckOfPlayer2.Count}");
            }
            else if (c2.Value > c1.Value)
            {
                label2.Text = ($"Player2 wins with {c2}  as the top card the top card");
                label1.Text = ($"Player1 lost with {c1}  as the top card the top card");
                deckOfPlayer2.Add(c1);
                deckOfPlayer1.Remove(c1);
                deckOfPlayer2.Add(c2);
                deckOfPlayer2.Remove(c2);
                label3.Text = ($"Player1 has {deckOfPlayer1.Count} ");
                label4.Text = ($"Player2 has {deckOfPlayer2.Count}");
            }

            else if (c2.Value == c1.Value)
            {

                label1.Text = ($"Player1 has {deckOfPlayer1[0].Name}{deckOfPlayer1[0].Suit} ");
                label2.Text = ($"Player2 has {deckOfPlayer2[0].Name}{deckOfPlayer2[0].Suit} ");

                label5.Text = ("Its a tie! Next three cards in deck are played face down, " +
                    "4th card face up, whoever has the highest card wins");

                if (deckOfPlayer1.Count < 4 || deckOfPlayer2.Count < 4)
                {
                    button1.Enabled = false;
                }

                // pick  The fourth random card for player 1

                Card c3 = deckOfPlayer1[3];

                // pick The fourth random card for player 2              

                Card c4 = deckOfPlayer2[3];

                if (c3.Value > c4.Value)
                {
                    deckOfPlayer1.Add(c4);
                    deckOfPlayer2.Remove(c4);
                    deckOfPlayer1.Add(c3);
                    deckOfPlayer1.Remove(c3);
                    Card card1 = deckOfPlayer2[0];
                    deckOfPlayer2.Remove(card1);
                    deckOfPlayer1.Add(card1);
                    Card card2 = deckOfPlayer2[1];
                    deckOfPlayer2.Remove(card2);
                    deckOfPlayer1.Add(card2);
                    Card card3 = deckOfPlayer2[2];
                    deckOfPlayer2.Remove(card3);
                    deckOfPlayer1.Add(card3);                 
                }
                else  
                {
                    deckOfPlayer2.Add(c3);
                    deckOfPlayer1.Remove(c3);
                    deckOfPlayer2.Add(c4);
                    deckOfPlayer2.Remove(c4);
                    Card card1 = deckOfPlayer1[0];
                    deckOfPlayer1.Remove(card1);
                    deckOfPlayer2.Add(card1);
                    Card card2 = deckOfPlayer1[1];
                    deckOfPlayer1.Remove(card2);
                    deckOfPlayer2.Add(card2);
                    Card card3 = deckOfPlayer1[2];
                    deckOfPlayer1.Remove(card3);
                    deckOfPlayer2.Add(card3);                    
                }

            }
            if (deckOfPlayer1.Count == 52 || deckOfPlayer2.Count < 4)
            {
                label6.Text = ($"Player1 is the Final Winner with {deckOfPlayer1.Count} cards ");
                button1.Enabled = false;
            }
            if (deckOfPlayer2.Count == 52 || deckOfPlayer1.Count < 4)
            {
                label6.Text = ($"Player2 is the Final Winner with {deckOfPlayer2.Count} cards ");
                button1.Enabled = false;
            }
            
        }
        
    }
}
